var mongoose = require('mongoose');

// Setup schema
var bookingSchema = mongoose.Schema({
    bookingId: {
        type: String,
        // required: true,
    },
    userId: {
        type: String,
        // required: true,
    },
    date: String,
    time: String,
    location: String
});

// Export food model
var booking = module.exports = mongoose.model('bookinglists', bookingSchema);

module.exports.get = function (callback, limit) {
    booking.find(callback).limit(limit);
}